<!-- Jilan Ablah Hanifah 2210511139 -->
<!DOCTYPE html>
<html>
<body>
    <?php
    echo "My first PHP Script!";
    ?>
</body>
</html>