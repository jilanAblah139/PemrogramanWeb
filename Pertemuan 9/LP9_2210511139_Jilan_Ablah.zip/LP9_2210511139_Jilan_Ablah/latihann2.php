<!-- Jilan Ablah Hanifah 2210511139 -->
<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $txt1 = "Learn PHP";
        $txt2 = "UPN Veteran Jakarta";
        $x = 5;
        $y = 4;

        echo "<h2>".$txt1."</h2>";
        echo "Study PHP at ". $txt2 . "  <br>";
        echo $x + $y;
        
    ?>
</body>
</html>