<!-- Jilan Ablah Hanifah 2210511139 -->
<?php
$penjumlahan = 2+4;
$pengurangan = 6-2;
$perkalian  = 3*5;
$pembagian   = 15/3;
$modulus     = 5%2;

echo "hasil: 2+4 =".$penjumlahan."<br>";
 echo "hasil : 6-2 =". $pengurangan ."<br>";
 echo "Hasil : 3 * 5= ". $perkalian. "<br>" ;
 echo  "Hasil : 15 / 3 =" . $pembagian . "<br> ";
 echo "Hasil : 5 % 2=".$modulus." <br> ";
?>