<!-- Jilan Ablah Hanifah 2210511139 -->
<?php
$x = 4; $x++;
echo "Nilai x yang baru:". $x."<br>";
$x = 4; $x--;
echo "Nilai x yang baru:". $x;

?>