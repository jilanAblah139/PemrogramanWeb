<!-- Jilan Ablah Hanifah 2210511139 -->
<?php
$teks = "Hello World!";
$sebuah_bilangan = 4;
$bilanganYangLain = 8.567;
$teks2 = $teks;

echo "<h1>".$teks."</h1>";
echo "<br>".$sebuah_bilangan;
echo  "<br/>Isi dari variable \$bilanganYangLain: ".$bilanganYangLain;
echo  "<br/>Isi dari variable \$teks2 adalah: ".$teks2;

?>