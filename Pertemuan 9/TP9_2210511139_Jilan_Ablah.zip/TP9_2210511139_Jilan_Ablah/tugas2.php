<!-- Jilan Ablah Hanifah 2210511139 -->
<?php
$bilangan = 100;
$pembagi = 3; 
$hasilBagi =  $bilangan / $pembagi;
$sisaBagi = $bilangan % $pembagi;
echo $bilangan." dibagi dengan ".$pembagi. " adalah ".number_format($hasilBagi, 0)." sisa ".$sisaBagi;
?>
